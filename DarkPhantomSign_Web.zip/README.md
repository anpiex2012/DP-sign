# DarkPhantom Sign — free Safari web prototype

This is a prototype with an English UI, dark purple theme, and supplied logo. It allows selecting an IPA file locally, entering a display name, and exporting a customization note.

## Limitations
It is not a native iOS app or full IPA editor. It does not rewrite IPA contents, replace embedded icons, sign, or install apps. The note is not a modified IPA.

## Host it for iPhone
The site must be published to an HTTPS static host:
1. Publish all folder contents to an HTTPS static host you control.
2. Open the published `index.html` URL in Safari on iPhone.
3. Tap Share → Add to Home Screen.

The ZIP is not an installable native iOS app. Do not upload IPA files to unknown websites.
